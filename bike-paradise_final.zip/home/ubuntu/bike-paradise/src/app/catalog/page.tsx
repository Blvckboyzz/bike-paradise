"use client";

import React, { useState, useEffect, useMemo } from 'react';
import ProductCard from "@/components/ProductCard";
import type { Bike } from "@/components/ProductCard";
import bikeData from "@/lib/bikeData.json";
import Link from "next/link";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider"; // Assuming you have a Slider component

const ALL_ITEMS = "Tous"; // For category and brand filters

export default function CatalogPage() {
  const allBikes: Bike[] = bikeData as Bike[];

  const [filteredBikes, setFilteredBikes] = useState<Bike[]>(allBikes);
  const [selectedCategory, setSelectedCategory] = useState<string>(ALL_ITEMS);
  const [selectedBrand, setSelectedBrand] = useState<string>(ALL_ITEMS);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 0]);
  const [currentPriceRange, setCurrentPriceRange] = useState<[number, number]>([0, 0]); // For slider interaction
  const [sortOption, setSortOption] = useState<string>("newest"); // newest, priceAsc, priceDesc

  const categories = useMemo(() => [ALL_ITEMS, ...Array.from(new Set(allBikes.map(bike => bike.category)))], [allBikes]);
  const brands = useMemo(() => [ALL_ITEMS, ...Array.from(new Set(allBikes.map(bike => bike.brand)))], [allBikes]);
  const maxPrice = useMemo(() => Math.max(...allBikes.map(bike => bike.estimatedPriceUSD), 0), [allBikes]);

  useEffect(() => {
    if (allBikes.length > 0) {
      const initialMax = Math.max(...allBikes.map(bike => bike.estimatedPriceUSD), 0);
      setPriceRange([0, initialMax]);
      setCurrentPriceRange([0, initialMax]);
    }
  }, [allBikes]);

  useEffect(() => {
    let tempBikes = [...allBikes];

    // Filter by category
    if (selectedCategory !== ALL_ITEMS) {
      tempBikes = tempBikes.filter(bike => bike.category === selectedCategory);
    }

    // Filter by brand
    if (selectedBrand !== ALL_ITEMS) {
      tempBikes = tempBikes.filter(bike => bike.brand === selectedBrand);
    }

    // Filter by price range
    tempBikes = tempBikes.filter(bike => bike.estimatedPriceUSD >= priceRange[0] && bike.estimatedPriceUSD <= priceRange[1]);

    // Sort bikes
    if (sortOption === "priceAsc") {
      tempBikes.sort((a, b) => a.estimatedPriceUSD - b.estimatedPriceUSD);
    } else if (sortOption === "priceDesc") {
      tempBikes.sort((a, b) => b.estimatedPriceUSD - a.estimatedPriceUSD);
    } else if (sortOption === "newest") {
      // Assuming higher ID means newer. If IDs are not sequential, this might need adjustment.
      tempBikes.sort((a, b) => parseInt(b.id) - parseInt(a.id)); 
    }

    setFilteredBikes(tempBikes);
  }, [selectedCategory, selectedBrand, priceRange, sortOption, allBikes]);

  const handlePriceRangeChange = (value: [number, number]) => {
    setCurrentPriceRange(value);
  };

  const applyPriceFilter = () => {
    setPriceRange(currentPriceRange);
  };
  
  const resetFilters = () => {
    setSelectedCategory(ALL_ITEMS);
    setSelectedBrand(ALL_ITEMS);
    const initialMax = Math.max(...allBikes.map(bike => bike.estimatedPriceUSD), 0);
    setPriceRange([0, initialMax]);
    setCurrentPriceRange([0, initialMax]);
    setSortOption("newest");
  };

  if (!allBikes.length) {
    return (
        <div className="container mx-auto px-4 py-8 text-center">
            <p className="text-xl text-gray-700 mb-4">Chargement des vélos...</p>
        </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold font-montserrat text-gray-800">Notre Catalogue de Vélos</h1>
        <p className="text-lg text-gray-600 mt-2">Découvrez notre sélection complète de vélos pour toutes vos aventures.</p>
      </div>

      {/* Filters and Sorting section */}
      <div className="mb-10 p-4 md:p-6 bg-gray-50 rounded-lg shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 items-end">
          {/* Category Filter */}
          <div>
            <label htmlFor="category-filter" className="block text-sm font-medium text-gray-700 mb-1">Catégorie</label>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger id="category-filter" className="w-full bg-white">
                <SelectValue placeholder="Choisir une catégorie" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Brand Filter */}
          <div>
            <label htmlFor="brand-filter" className="block text-sm font-medium text-gray-700 mb-1">Marque</label>
            <Select value={selectedBrand} onValueChange={setSelectedBrand}>
              <SelectTrigger id="brand-filter" className="w-full bg-white">
                <SelectValue placeholder="Choisir une marque" />
              </SelectTrigger>
              <SelectContent>
                {brands.map(brand => (
                  <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Price Range Filter */}
          <div className="md:col-span-2 lg:col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Gamme de prix</label>
            <div className="flex items-center gap-2 mb-2">
                <Input type="number" value={currentPriceRange[0]} onChange={(e) => setCurrentPriceRange([+e.target.value, currentPriceRange[1]])} className="w-full bg-white" placeholder="Min" />
                <span>-</span>
                <Input type="number" value={currentPriceRange[1]} onChange={(e) => setCurrentPriceRange([currentPriceRange[0], +e.target.value])} className="w-full bg-white" placeholder="Max" />
            </div>
            <Slider 
                min={0} 
                max={maxPrice} 
                step={50} 
                value={currentPriceRange} 
                onValueChange={handlePriceRangeChange} 
                className="w-full"
            />
            <Button onClick={applyPriceFilter} className="w-full mt-2 bg-[#5e2ca5] hover:bg-purple-700 text-white">Appliquer Prix</Button>
          </div>

          {/* Sort Options */}
          <div>
            <label htmlFor="sort-options" className="block text-sm font-medium text-gray-700 mb-1">Trier par</label>
            <Select value={sortOption} onValueChange={setSortOption}>
              <SelectTrigger id="sort-options" className="w-full bg-white">
                <SelectValue placeholder="Trier par" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Nouveautés</SelectItem>
                <SelectItem value="priceAsc">Prix croissant</SelectItem>
                <SelectItem value="priceDesc">Prix décroissant</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="mt-4 text-right">
            <Button onClick={resetFilters} variant="outline" className="text-[#5e2ca5] border-[#5e2ca5] hover:bg-purple-50">Réinitialiser les filtres</Button>
        </div>
      </div>

      {filteredBikes.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 lg:gap-8">
          {filteredBikes.map((bike) => (
            <ProductCard key={bike.id} bike={bike} />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <p className="text-xl text-gray-700 mb-4">Aucun vélo ne correspond à vos critères de recherche.</p>
          <Link href="/catalog" onClick={resetFilters} 
            className="text-[#5e2ca5] hover:underline font-semibold"
          >
            Voir tous les vélos
          </Link>
        </div>
      )}
    </div>
  );
}

