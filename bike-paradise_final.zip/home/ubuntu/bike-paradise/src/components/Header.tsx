import Link from "next/link";

const Header = () => {
  return (
    <header className="bg-[#5e2ca5] text-white p-4 shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex flex-wrap justify-between items-center">
        <Link href="/" className="text-3xl font-bold font-montserrat">
          Bike Paradise
        </Link>
        <nav className="mt-2 md:mt-0">
          <ul className="flex flex-wrap space-x-3 md:space-x-4 text-sm md:text-base">
            <li><Link href="/" className="hover:text-gray-300 transition-colors">Accueil</Link></li>
            <li><Link href="/catalog" className="hover:text-gray-300 transition-colors">Catalogue</Link></li>
            <li><Link href="/brands" className="hover:text-gray-300 transition-colors">Nos Marques</Link></li>
            <li><Link href="/categories" className="hover:text-gray-300 transition-colors">Catégories</Link></li>
            <li><Link href="/contact" className="hover:text-gray-300 transition-colors">Contact</Link></li>
            {/* Add other links like Cart, Account later if needed */}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;

