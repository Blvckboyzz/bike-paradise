import type { Metadata } from "next";
import { Open_Sans, Montserrat } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header"; // Assuming Header will be created
import Footer from "@/components/Footer"; // Assuming Footer will be created

const openSans = Open_Sans({
  subsets: ["latin"],
  variable: "--font-open-sans",
  display: "swap",
});

const montserrat = Montserrat({
  subsets: ["latin"],
  variable: "--font-montserrat",
  weight: ["400", "700"], // Include weights needed
  display: "swap",
});

export const metadata: Metadata = {
  title: "Bike Paradise - Explorez la liberté. Roulez avec passion.",
  description: "Découvrez notre sélection de vélos de haute qualité. Bike Paradise, votre destination pour l'aventure à deux roues.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" className={`${openSans.variable} ${montserrat.variable}`}>
      <body className="antialiased flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}

