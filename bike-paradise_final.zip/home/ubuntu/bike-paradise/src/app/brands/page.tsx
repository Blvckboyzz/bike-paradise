"use client";

import Link from 'next/link';
import bikeData from "@/lib/bikeData.json";
import type { Bike } from "@/components/ProductCard";
import { useMemo } from 'react';

// Helper function to generate a simple placeholder logo (e.g., initials or a generic icon)
const BrandLogoPlaceholder = ({ brandName }: { brandName: string }) => {
  return (
    <div className="w-32 h-16 bg-gray-200 flex items-center justify-center rounded-md text-gray-500 font-semibold">
      {brandName.substring(0, 3).toUpperCase()}
    </div>
  );
};

export default function BrandsPage() {
  const allBikes: Bike[] = bikeData as Bike[];
  const brands = useMemo(() => {
    const uniqueBrands = Array.from(new Set(allBikes.map(bike => bike.brand)));
    return uniqueBrands.sort(); // Sort brands alphabetically
  }, [allBikes]);

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold font-montserrat text-gray-800">Nos Marques Partenaires</h1>
        <p className="text-lg text-gray-600 mt-2">Découvrez les marques de vélos que nous proposons, sélectionnées pour leur qualité et leur innovation.</p>
      </div>

      {brands.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 md:gap-8">
          {brands.map((brand) => (
            <Link key={brand} href={`/catalog?brand=${encodeURIComponent(brand)}`} passHref legacyBehavior>
              <a className="block p-4 bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 ease-in-out flex flex-col items-center text-center">
                {/* Placeholder for actual logo - replace with <Image /> if logos are available */}
                <BrandLogoPlaceholder brandName={brand} />
                <h2 className="text-xl font-semibold font-montserrat text-gray-700 mt-4">{brand}</h2>
                <p className="text-sm text-[#5e2ca5] hover:underline mt-1">Voir les modèles</p>
              </a>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <p className="text-xl text-gray-700">Aucune marque à afficher pour le moment.</p>
        </div>
      )}
    </div>
  );
}

