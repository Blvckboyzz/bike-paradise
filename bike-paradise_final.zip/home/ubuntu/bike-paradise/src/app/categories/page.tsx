"use client";

import Link from 'next/link';
import Image from 'next/image'; // For category images if available
import bikeData from "@/lib/bikeData.json";
import type { Bike } from "@/components/ProductCard";
import { useMemo } from 'react';

// Placeholder for category images - in a real scenario, these would be specific to each category
const categoryImagePlaceholders: { [key: string]: string } = {
  default: "/placeholder-category.jpg", // A generic placeholder
  "Road Bikes": "/road-bikes-category.jpg",
  "Mountain Bikes": "/mtb-category.jpg",
  "Bikepacking & Touring Bikes": "/touring-bikes-category.jpg",
  "Framesets": "/framesets-category.jpg",
  // Add more specific placeholders as needed
};

const getCategoryImage = (categoryName: string) => {
  // A simple logic to pick a more specific image or a default one
  // This could be expanded with actual image URLs if provided in data
  return categoryImagePlaceholders[categoryName] || categoryImagePlaceholders.default;
};

export default function CategoriesPage() {
  const allBikes: Bike[] = bikeData as Bike[];
  const categories = useMemo(() => {
    const uniqueCategories = Array.from(new Set(allBikes.map(bike => bike.category)));
    return uniqueCategories.sort(); // Sort categories alphabetically
  }, [allBikes]);

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold font-montserrat text-gray-800">Explorez par Catégorie</h1>
        <p className="text-lg text-gray-600 mt-2">Trouvez le vélo parfait en naviguant à travers nos différentes catégories.</p>
      </div>

      {categories.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {categories.map((category) => (
            <Link key={category} href={`/catalog?category=${encodeURIComponent(category)}`} passHref legacyBehavior>
              <a className="block group relative rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 ease-in-out aspect-video md:aspect-[4/3]">
                {/* Placeholder for actual category image */}
                {/* In a real app, you would use <Image /> from Next.js with proper src */}
                <div className="absolute inset-0 bg-black opacity-30 group-hover:opacity-50 transition-opacity duration-300 z-10"></div>
                <Image 
                    src={getCategoryImage(category)} // Replace with actual image logic
                    alt={`Image catégorie ${category}`}
                    layout="fill"
                    objectFit="cover"
                    className="transform group-hover:scale-110 transition-transform duration-500 ease-in-out"
                    onError={(e) => { (e.target as HTMLImageElement).src = categoryImagePlaceholders.default; }} // Fallback
                />
                <div className="absolute inset-0 flex items-center justify-center z-20 p-4">
                  <h2 className="text-2xl md:text-3xl font-bold font-montserrat text-white text-center leading-tight">
                    {category}
                  </h2>
                </div>
              </a>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <p className="text-xl text-gray-700">Aucune catégorie à afficher pour le moment.</p>
        </div>
      )}
    </div>
  );
}

