import Link from "next/link";

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-8 mt-auto">
      <div className="container mx-auto px-4 text-center">
        <div className="mb-4">
          <Link href="/" className="text-2xl font-bold font-montserrat text-[#5e2ca5]">
            Bike Paradise
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-sm">
          <div>
            <h5 className="font-bold mb-2 font-montserrat">Légal</h5>
            <Link href="/terms" className="hover:text-gray-300 block">Conditions Générales de Vente</Link>
            <Link href="/privacy" className="hover:text-gray-300 block">Politique de Confidentialité</Link>
            <Link href="/legal-notice" className="hover:text-gray-300 block">Mentions Légales</Link>
          </div>
          <div>
            <h5 className="font-bold mb-2 font-montserrat">Navigation</h5>
            <Link href="/catalog" className="hover:text-gray-300 block">Catalogue</Link>
            <Link href="/brands" className="hover:text-gray-300 block">Nos Marques</Link>
            <Link href="/categories" className="hover:text-gray-300 block">Catégories</Link>
            <Link href="/contact" className="hover:text-gray-300 block">Contact / Support</Link>
          </div>
          <div>
            <h5 className="font-bold mb-2 font-montserrat">Suivez-nous</h5>
            {/* Add social media icons/links here */}
            <p>Facebook | Instagram | Twitter</p> {/* Placeholder */} 
            <p className="mt-2">123 Bike Lane, Cycle City, CA 90210, USA (Fictive)</p>
          </div>
        </div>
        <p className="text-xs text-gray-400">
          &copy; {new Date().getFullYear()} Bike Paradise. Tous droits réservés.
        </p>
      </div>
    </footer>
  );
};

export default Footer;

