"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast"; // Assuming a toast hook for notifications
import { useState } from "react";

export default function ContactPage() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSubmitting(false);
    toast({
      title: "Message Envoyé !",
      description: "Merci de nous avoir contactés. Nous reviendrons vers vous bientôt.",
      variant: "default", // Or "success" if you have such a variant
    });
    setFormData({ name: "", email: "", subject: "", message: "" }); // Reset form
  };

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold font-montserrat text-gray-800">Contactez-Nous</h1>
        <p className="text-lg text-gray-600 mt-2">Une question ? Une suggestion ? N’hésitez pas à nous écrire.</p>
      </div>

      <div className="max-w-2xl mx-auto bg-white p-6 md:p-8 rounded-lg shadow-xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Nom complet</label>
            <Input 
              type="text" 
              name="name" 
              id="name" 
              required 
              value={formData.name}
              onChange={handleChange}
              placeholder="Votre nom complet"
              className="w-full bg-gray-50 border-gray-300"
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Adresse e-mail</label>
            <Input 
              type="email" 
              name="email" 
              id="email" 
              required 
              value={formData.email}
              onChange={handleChange}
              placeholder="votreadresse@example.com"
              className="w-full bg-gray-50 border-gray-300"
            />
          </div>
          <div>
            <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">Sujet</label>
            <Input 
              type="text" 
              name="subject" 
              id="subject" 
              required 
              value={formData.subject}
              onChange={handleChange}
              placeholder="Sujet de votre message"
              className="w-full bg-gray-50 border-gray-300"
            />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Votre message</label>
            <Textarea 
              name="message" 
              id="message" 
              rows={5} 
              required 
              value={formData.message}
              onChange={handleChange}
              placeholder="Écrivez votre message ici..."
              className="w-full bg-gray-50 border-gray-300"
            />
          </div>
          <div>
            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full bg-[#5e2ca5] hover:bg-purple-700 text-white font-bold py-3 px-6 text-lg font-montserrat transition-colors duration-300 disabled:opacity-70"
            >
              {isSubmitting ? "Envoi en cours..." : "Envoyer le Message"}
            </Button>
          </div>
        </form>
      </div>
      
      {/* You might want to add a Toaster component in your RootLayout for the toast notifications to appear */}
      {/* e.g. in layout.tsx: import { Toaster } from "@/components/ui/toaster"; ... <Toaster /> */}
    </div>
  );
}

