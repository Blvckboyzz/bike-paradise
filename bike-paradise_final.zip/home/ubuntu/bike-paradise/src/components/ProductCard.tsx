import React from "next/link";
import Image from "next/image";

// Updated Bike interface to match bikeData.json structure
export interface Bike {
  id: string;
  category: string;
  brand: string;
  model: string;
  estimatedPriceUSD: number;
  reducedPriceUSD: number | null;
  imageUrl: string;
  productUrl: string;
}

interface ProductCardProps {
  bike: Bike;
}

const ProductCard: React.FC<ProductCardProps> = ({ bike }) => {
  const discountedPrice = bike.reducedPriceUSD;
  const originalPrice = bike.estimatedPriceUSD;

  return (
    <div className="border border-gray-200 rounded-lg shadow-lg overflow-hidden bg-white hover:shadow-xl transition-shadow duration-300 flex flex-col h-full">
      <Link href={bike.productUrl} passHref legacyBehavior>
        <a target="_blank" rel="noopener noreferrer" className="block aspect-[4/3] overflow-hidden">
          <Image 
            src={bike.imageUrl}
            alt={`Image de ${bike.model}`}
            width={400} // Provide explicit width for better performance and layout stability
            height={300} // Provide explicit height
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => { (e.target as HTMLImageElement).src = "/placeholder-image.jpg"; }} // Fallback image
          />
        </a>
      </Link>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-semibold text-gray-800 mb-1 font-montserrat truncate" title={bike.model}>{bike.model}</h3>
        <p className="text-sm text-gray-600 mb-2">{bike.brand} - <span className="italic">{bike.category}</span></p>
        
        <div className="mt-auto">
          <div className="mb-3 flex items-baseline justify-start">
            {discountedPrice && discountedPrice < originalPrice ? (
              <>
                <p className="text-2xl font-bold text-red-600">${discountedPrice.toFixed(2)}</p>
                <p className="text-md text-gray-500 line-through ml-2">${originalPrice.toFixed(2)}</p>
              </>
            ) : (
              <p className="text-2xl font-bold text-gray-800">${originalPrice.toFixed(2)}</p>
            )}
          </div>
          <Link href={`/catalog/${bike.id}`} passHref legacyBehavior>
            <a className="block w-full bg-[#5e2ca5] text-white font-semibold py-2 px-4 rounded-md text-center hover:bg-purple-700 transition duration-300 ease-in-out font-montserrat">
              Voir plus
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;

