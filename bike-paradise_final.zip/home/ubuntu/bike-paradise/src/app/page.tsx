import Link from "next/link";
import Image from "next/image";

// Placeholder for customer reviews data
const customerReviews = [
  {
    id: 1,
    name: "Alex R., San Francisco, CA",
    quote: "Le site Bike Paradise est incroyablement intuitif. J'ai trouvé le vélo de mes rêves en quelques clics seulement !",
    highlight: "Efficacité du site"
  },
  {
    id: 2,
    name: "Maria G., Austin, TX",
    quote: "J'ai été bluffée par la rapidité de la livraison. Mon nouveau VTT est arrivé en parfait état et plus tôt que prévu.",
    highlight: "Rapidité de livraison"
  },
  {
    id: 3,
    name: "John B., Denver, CO",
    quote: "Le catalogue est très clair et bien organisé. Les descriptions des vélos sont complètes et les photos de haute qualité.",
    highlight: "Clarté du catalogue"
  },
  {
    id: 4,
    name: "Lisa P., Seattle, WA",
    quote: "Un service client exceptionnel ! Ils ont répondu à toutes mes questions avec patience et professionnalisme.",
    highlight: "Service client"
  },
  {
    id: 5,
    name: "David K., Portland, OR",
    quote: "La qualité des vélos est irréprochable. On sent la passion et l'expertise derrière chaque modèle proposé.",
    highlight: "Qualité des vélos"
  },
  {
    id: 6,
    name: "Sarah W., Miami, FL",
    quote: "Les réductions sont vraiment avantageuses. J'ai pu m'offrir un vélo haut de gamme à un prix défiant toute concurrence.",
    highlight: "Réductions avantageuses"
  }
];

const WhyChooseUs = () => {
  return (
    <section className="py-12 md:py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-10 md:mb-16 font-montserrat text-gray-800">Pourquoi nous choisir ?</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {customerReviews.map((review) => (
            <div key={review.id} className="bg-gray-50 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
              <h3 className="text-xl font-semibold mb-2 font-montserrat text-[#5e2ca5]">{review.highlight}</h3>
              <p className="text-gray-600 mb-3 text-sm leading-relaxed">{`\"${review.quote}\"`}</p>
              <p className="text-gray-500 text-xs font-medium">- {review.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default function HomePage() {
  return (
    <>
      {/* Hero Banner */}
      <section className="relative hero-bg-image text-white py-20 md:py-32 lg:py-48 flex items-center justify-center text-center min-h-[60vh] md:min-h-[75vh]">
        <div className="absolute inset-0 bg-black opacity-40"></div> {/* Overlay for better text readability */}
        <div className="relative z-10 container mx-auto px-4">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 leading-tight font-montserrat">
            Explorez la liberté. Roulez avec passion.
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            Votre aventure commence ici. Découvrez notre sélection exclusive de vélos conçus pour la performance et le plaisir.
          </p>
          <Link
            href="/catalog"
            className="bg-white text-[#5e2ca5] font-bold py-3 px-8 rounded-lg text-lg hover:bg-gray-100 transition duration-300 ease-in-out transform hover:scale-105 font-montserrat"
          >
            Voir les modèles
          </Link>
        </div>
      </section>

      {/* Pourquoi nous choisir Section */}
      <WhyChooseUs />
      
      {/* Other sections can be added here */}
    </>
  );
}

