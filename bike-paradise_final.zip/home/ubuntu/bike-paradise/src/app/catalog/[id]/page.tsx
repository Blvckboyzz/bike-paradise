"use client";

import { useParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import bikeData from "@/lib/bikeData.json";
import type { Bike } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from 'react';

// Function to generate a placeholder description
const generateDescription = (bike: Bike): string => {
  return `Découvrez le ${bike.model} de la marque ${bike.brand}, un vélo exceptionnel dans la catégorie ${bike.category.toLowerCase()}. Conçu pour offrir des performances optimales et un confort inégalé, ce modèle est parfait pour les passionnés exigeants. Son cadre robuste, ses composants de haute qualité et son design élégant en font un choix idéal pour toutes vos aventures. Profitez d'une expérience de cyclisme supérieure avec le ${bike.model}.`;
};

export default function ProductDetailPage() {
  const params = useParams();
  const productId = params?.id as string;
  const [bike, setBike] = useState<Bike | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (productId) {
      const foundBike = (bikeData as Bike[]).find(b => b.id === productId);
      setBike(foundBike || null);
    }
    setLoading(false);
  }, [productId]);

  if (loading) {
    return <div className="container mx-auto px-4 py-8 text-center"><p>Chargement du produit...</p></div>;
  }

  if (!bike) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">Produit non trouvé</h1>
        <p className="mb-4">Désolé, le vélo que vous cherchez n'existe pas ou plus.</p>
        <Link href="/catalog"
          className="bg-[#5e2ca5] text-white font-semibold py-2 px-6 rounded-md hover:bg-purple-700 transition duration-300 ease-in-out font-montserrat"
        >
          Retour au catalogue
        </Link>
      </div>
    );
  }

  const description = bike.description || generateDescription(bike); // Assuming 'description' could be a field in Bike interface

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 items-start">
        {/* Image Section */}
        <div className="w-full aspect-[4/3] relative rounded-lg overflow-hidden shadow-lg">
          <Image 
            src={bike.imageUrl}
            alt={`Image de ${bike.model}`}
            layout="fill"
            objectFit="cover"
            className="transform transition-transform duration-500 hover:scale-105"
            onError={(e) => { (e.target as HTMLImageElement).src = "/placeholder-image.jpg"; }}
          />
        </div>

        {/* Details Section */}
        <div className="flex flex-col">
          <h1 className="text-3xl md:text-4xl font-bold font-montserrat text-gray-800 mb-3">{bike.model}</h1>
          <p className="text-lg text-gray-600 mb-1"><span className="font-semibold">Marque:</span> {bike.brand}</p>
          <p className="text-lg text-gray-600 mb-4"><span className="font-semibold">Catégorie:</span> {bike.category}</p>
          
          <div className="mb-6">
            {bike.reducedPriceUSD && bike.reducedPriceUSD < bike.estimatedPriceUSD ? (
              <div className="flex items-baseline gap-3">
                <p className="text-4xl font-bold text-red-600">${bike.reducedPriceUSD.toFixed(2)}</p>
                <p className="text-2xl text-gray-500 line-through">${bike.estimatedPriceUSD.toFixed(2)}</p>
              </div>
            ) : (
              <p className="text-4xl font-bold text-gray-800">${bike.estimatedPriceUSD.toFixed(2)}</p>
            )}
            <p className="text-sm text-green-600 mt-1">En stock</p> {/* Placeholder for stock status */}
          </div>

          <div className="mb-6">
            <h2 className="text-xl font-semibold font-montserrat text-gray-700 mb-2">Description</h2>
            <p className="text-gray-700 leading-relaxed text-justify">{description}</p>
          </div>

          {/* Add to Cart Button */}
          <Button 
            size="lg"
            className="w-full md:w-auto bg-[#5e2ca5] hover:bg-purple-700 text-white font-bold py-3 px-8 text-lg font-montserrat transition-transform duration-200 hover:scale-105"
            onClick={() => console.log(`Ajout au panier: ${bike.id}`)} // Placeholder for cart functionality
          >
            Ajouter au panier
          </Button>

          <div className="mt-8 border-t pt-6">
            <h3 className="text-lg font-semibold font-montserrat text-gray-700 mb-2">Caractéristiques Clés (Exemple)</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-1">
                <li>Cadre en aluminium léger et résistant</li>
                <li>Transmission Shimano 21 vitesses</li>
                <li>Freins à disque hydrauliques pour un freinage puissant</li>
                <li>Pneus tout-terrain polyvalents</li>
            </ul>
          </div>

        </div>
      </div>

      {/* Related Products Section - Placeholder */}
      {/* <div className="mt-16 pt-8 border-t">
        <h2 className="text-2xl font-bold text-center mb-8 font-montserrat text-gray-800">Vous pourriez aussi aimer</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          Placeholder for related products
        </div>
      </div> */}
    </div>
  );
}

// Add a placeholder for the description field in the Bike interface if it doesn't exist
// This should be done in ProductCard.tsx or a shared types file
// For example, in ProductCard.tsx or a new src/types/index.ts:
// export interface Bike {
//   id: string;
//   category: string;
//   brand: string;
//   model: string;
//   estimatedPriceUSD: number;
//   reducedPriceUSD: number | null;
//   imageUrl: string;
//   productUrl: string;
//   description?: string; // Optional description field
// }

